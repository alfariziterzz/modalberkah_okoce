<img src="{{ asset('assets/img/mesjid.png') }}" height="{{ $height }}" alt="">
<img src="{{ asset('assets/img/logo.png') }}" height="{{ $height }}" alt="">
