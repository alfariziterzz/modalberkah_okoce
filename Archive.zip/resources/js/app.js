/*
This file will be used by jetstream to add alpine.js. This file must exist to install jetstream successfully.
You can remove it if you don't want to use jetstream.
*/
