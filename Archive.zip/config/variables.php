<?php
// Variables
return [
  "creatorName" => "Modal Berkah",
  "creatorUrl" => "https://modalberkah.com/",
  "templateName" => "MB",
  "templateSuffix" => "Modal Berkah",
  "templateVersion" => "1.0.0",
  "templateFree" => false,
  "templateDescription" => "Modal Berkah",
  "templateKeyword" => "#",
  "licenseUrl" => "#",
  "livePreview" => "#",
  "productPage" => "#",
  "support" => "#",
  "moreThemes" => "#",
  "documentation" => "#",
  "generator" => "",
  "changelog" => "#",
  "repository" => "#",
  "gitRepo" => "pixinvent",
  "gitRepoAccess" => "vuexy-html-admin-template",
  "githubFreeUrl" => "#",
  "facebookUrl" => "#",
  "twitterUrl" => "#",
  "githubUrl" => "#",
  "dribbbleUrl" => "#",
  "instagramUrl" => "#"
];
